#ifndef GLOBALS_H
#define GLOBALS_H

extern int START;
extern int LINE;
extern char* BUFFER;

void updateLine(char* line);
int initializeGlobals();

#endif // GLOBALS_H
